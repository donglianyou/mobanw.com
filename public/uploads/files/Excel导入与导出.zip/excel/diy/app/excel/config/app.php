<?php

/**
 * Dayrui Website Management System
 * 
 * @since			version 2.0.0
 * @author			Dayrui <dayrui@gmail.com>
 * @license     	http://www.dayrui.com/license
 * @copyright		Copyright (c) 2011 - 9999, Dayrui.Com, Inc.
 */

/**
 * 应用配置
 */

return array(

	'key'			=> 158, // 官方应用商城上线的id号
	'name'			=> 'Excel导入与导出',
	'author'		=> 'FineCMS设计室',
	'version'		=> '1.0',

);