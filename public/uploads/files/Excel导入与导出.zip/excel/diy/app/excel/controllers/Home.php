<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Test
 *
 * @since		version 1.0.0
 * @author		Dayrui <dayrui@gmail.com>
 * @license     http://www.dayrui.com/license
 * @copyright   Copyright (c) 2011 - 9999, Dayrui.Com, Inc.
 */

class Home extends M_Controller {

    /**
     * 构造函数
     */
    public function __construct() {
        parent::__construct();
    }

    /**
     * 前端首页控制器
     */
    public function index() {


        
    }

}