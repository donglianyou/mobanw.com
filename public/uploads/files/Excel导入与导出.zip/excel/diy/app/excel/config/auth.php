<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * 应用的权限认证列表
 */

$config['auth'][] = array(
	'auth' => array(
	)
);