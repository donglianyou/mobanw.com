-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2018 �?09 �?17 �?16:51
-- 服务器版本: 5.5.54-log
-- PHP 版本: 5.6.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `mobanw.cn`
--

-- --------------------------------------------------------

--
-- 表的结构 `admin_menu`
--

CREATE TABLE IF NOT EXISTS `admin_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uri` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=28 ;

--
-- 转存表中的数据 `admin_menu`
--

INSERT INTO `admin_menu` (`id`, `parent_id`, `order`, `title`, `icon`, `uri`, `created_at`, `updated_at`) VALUES
(1, 0, 1, '首页', 'fa-home', '/', NULL, '2018-09-16 18:57:03'),
(2, 0, 11, '用户设置', 'fa-users', NULL, NULL, '2018-09-16 23:55:46'),
(3, 2, 12, '用户管理', 'fa-user-plus', 'auth/users', NULL, '2018-09-16 23:55:46'),
(4, 2, 13, '角色管理', 'fa-user', 'auth/roles', NULL, '2018-09-16 23:55:46'),
(5, 2, 14, '权限管理', 'fa-ban', 'auth/permissions', NULL, '2018-09-16 23:55:46'),
(6, 2, 15, '菜单管理', 'fa-bars', 'auth/menu', NULL, '2018-09-16 23:55:46'),
(7, 2, 16, '操作日志', 'fa-book', 'auth/logs', NULL, '2018-09-16 23:55:46'),
(8, 0, 7, '会员管理', 'fa-user-md', NULL, '2018-09-16 22:29:24', '2018-09-16 23:40:01'),
(9, 8, 8, '会员列表', 'fa-user-plus', '/users', '2018-09-16 22:30:43', '2018-09-16 23:40:01'),
(10, 0, 17, '广告管理', 'fa-bullhorn', NULL, '2018-09-16 22:51:51', '2018-09-16 23:55:46'),
(11, 10, 18, '广告列表', 'fa-image', '/ads', '2018-09-16 22:59:39', '2018-09-16 23:55:46'),
(12, 0, 9, '系统管理', 'fa-cog', NULL, '2018-09-16 23:01:46', '2018-09-16 23:40:01'),
(13, 0, 19, '统计管理', 'fa-bar-chart-o', NULL, '2018-09-16 23:11:23', '2018-09-16 23:55:46'),
(14, 13, 20, '统计列表', 'fa-pie-chart', 'chart', '2018-09-16 23:12:35', '2018-09-16 23:55:46'),
(15, 0, 2, '文章管理', 'fa-send-o', NULL, '2018-09-16 23:16:10', '2018-09-16 23:26:37'),
(16, 15, 3, '文章分类', 'fa-list-alt', 'category', '2018-09-16 23:21:41', '2018-09-16 23:26:37'),
(17, 15, 4, '文章列表', 'fa-list-ol', 'articles', '2018-09-16 23:22:01', '2018-09-16 23:26:37'),
(18, 0, 21, '数据库管理', 'fa-database', NULL, '2018-09-16 23:27:54', '2018-09-16 23:55:46'),
(19, 0, 5, '订单管理', 'fa-cart-plus', NULL, '2018-09-16 23:38:18', '2018-09-16 23:40:01'),
(20, 19, 6, '订单列表', 'fa-ambulance', 'orders', '2018-09-16 23:39:35', '2018-09-16 23:40:01'),
(21, 0, 24, '积分管理', 'fa-money', NULL, '2018-09-16 23:44:22', '2018-09-16 23:56:28'),
(22, 21, 25, '积分兑换', 'fa-balance-scale', 'exchange', '2018-09-16 23:46:07', '2018-09-16 23:56:28'),
(23, 0, 26, '支付方式', 'fa-cc-paypal', 'payment', '2018-09-16 23:46:41', '2018-09-16 23:56:28'),
(24, 12, 10, '系统设置', 'fa-cogs', 'setting', '2018-09-16 23:49:13', '2018-09-16 23:55:46'),
(25, 18, 22, '数据库备份', 'fa-arrow-down', 'backup', '2018-09-16 23:55:34', '2018-09-16 23:55:46'),
(26, 18, 23, '数据库还原', 'fa-arrow-up', 'restore', '2018-09-16 23:56:21', '2018-09-16 23:56:28'),
(27, 0, 0, '评论管理', 'fa-comments', 'comment', '2018-09-17 00:32:13', '2018-09-17 00:32:13');

-- --------------------------------------------------------

--
-- 表的结构 `admin_operation_log`
--

CREATE TABLE IF NOT EXISTS `admin_operation_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `input` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_operation_log_user_id_index` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=297 ;

--
-- 转存表中的数据 `admin_operation_log`
--

INSERT INTO `admin_operation_log` (`id`, `user_id`, `path`, `method`, `ip`, `input`, `created_at`, `updated_at`) VALUES
(1, 1, 'admin', 'GET', '192.168.6.49', '[]', '2018-09-16 18:53:51', '2018-09-16 18:53:51'),
(2, 1, 'admin', 'GET', '192.168.6.49', '[]', '2018-09-16 18:53:55', '2018-09-16 18:53:55'),
(3, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:54:00', '2018-09-16 18:54:00'),
(4, 1, 'admin/auth/users', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:54:04', '2018-09-16 18:54:04'),
(5, 1, 'admin/auth/roles', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:54:05', '2018-09-16 18:54:05'),
(6, 1, 'admin/auth/permissions', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:54:06', '2018-09-16 18:54:06'),
(7, 1, 'admin/auth/permissions', 'GET', '192.168.6.49', '[]', '2018-09-16 18:55:27', '2018-09-16 18:55:27'),
(8, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:55:31', '2018-09-16 18:55:31'),
(9, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:55:32', '2018-09-16 18:55:32'),
(10, 1, 'admin/auth/users', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:55:34', '2018-09-16 18:55:34'),
(11, 1, 'admin/auth/users', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:55:36', '2018-09-16 18:55:36'),
(12, 1, 'admin/auth/roles', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:55:37', '2018-09-16 18:55:37'),
(13, 1, 'admin/auth/permissions', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:55:39', '2018-09-16 18:55:39'),
(14, 1, 'admin/auth/users', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:55:40', '2018-09-16 18:55:40'),
(15, 1, 'admin/auth/users', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:55:49', '2018-09-16 18:55:49'),
(16, 1, 'admin/auth/roles', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:55:51', '2018-09-16 18:55:51'),
(17, 1, 'admin/auth/permissions', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:55:53', '2018-09-16 18:55:53'),
(18, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:55:55', '2018-09-16 18:55:55'),
(19, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:55:56', '2018-09-16 18:55:56'),
(20, 1, 'admin/auth/menu/1/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:56:08', '2018-09-16 18:56:08'),
(21, 1, 'admin/auth/menu/1', 'PUT', '192.168.6.49', '{"parent_id":"0","title":"\\u9996\\u9875","icon":"fa-bar-chart","uri":"\\/","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/menu"}', '2018-09-16 18:56:24', '2018-09-16 18:56:24'),
(22, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 18:56:24', '2018-09-16 18:56:24'),
(23, 1, 'admin/auth/menu/1/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:56:30', '2018-09-16 18:56:30'),
(24, 1, 'admin/auth/menu/1', 'PUT', '192.168.6.49', '{"parent_id":"0","title":"\\u9996\\u9875","icon":"fa-bar-chart","uri":"\\/","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/menu"}', '2018-09-16 18:56:46', '2018-09-16 18:56:46'),
(25, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 18:56:46', '2018-09-16 18:56:46'),
(26, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:56:48', '2018-09-16 18:56:48'),
(27, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:56:50', '2018-09-16 18:56:50'),
(28, 1, 'admin/auth/menu/1/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:56:53', '2018-09-16 18:56:53'),
(29, 1, 'admin/auth/menu/1', 'PUT', '192.168.6.49', '{"parent_id":"0","title":"\\u9996\\u9875","icon":"fa-home","uri":"\\/","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/menu"}', '2018-09-16 18:57:03', '2018-09-16 18:57:03'),
(30, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 18:57:03', '2018-09-16 18:57:03'),
(31, 1, 'admin/auth/menu/1/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:57:07', '2018-09-16 18:57:07'),
(32, 1, 'admin/auth/users', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:57:16', '2018-09-16 18:57:16'),
(33, 1, 'admin/auth/users/1/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:57:18', '2018-09-16 18:57:18'),
(34, 1, 'admin/auth/users/1', 'PUT', '192.168.6.49', '{"username":"admin","name":"\\u8d85\\u7ea7\\u7ba1\\u7406\\u5458","password":"$2y$10$rlHvYcF9sfTiC0RmA28trOED2ro2p0pXj0Ld3OYaCRroeL9TNmqwi","password_confirmation":"$2y$10$rlHvYcF9sfTiC0RmA28trOED2ro2p0pXj0Ld3OYaCRroeL9TNmqwi","roles":["1",null],"permissions":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/users"}', '2018-09-16 18:57:58', '2018-09-16 18:57:58'),
(35, 1, 'admin/auth/users/1/edit', 'GET', '192.168.6.49', '[]', '2018-09-16 18:57:58', '2018-09-16 18:57:58'),
(36, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:58:07', '2018-09-16 18:58:07'),
(37, 1, 'admin/auth/users', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:58:09', '2018-09-16 18:58:09'),
(38, 1, 'admin/auth/users/1/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:58:12', '2018-09-16 18:58:12'),
(39, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:58:31', '2018-09-16 18:58:31'),
(40, 1, 'admin/auth/roles', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:58:38', '2018-09-16 18:58:38'),
(41, 1, 'admin/auth/roles/1/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:58:44', '2018-09-16 18:58:44'),
(42, 1, 'admin/auth/roles/1', 'PUT', '192.168.6.49', '{"slug":"admin","name":"\\u8d85\\u7ea7\\u7ba1\\u7406\\u5458","permissions":["1",null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/roles"}', '2018-09-16 18:59:11', '2018-09-16 18:59:11'),
(43, 1, 'admin/auth/roles', 'GET', '192.168.6.49', '[]', '2018-09-16 18:59:11', '2018-09-16 18:59:11'),
(44, 1, 'admin/auth/roles/1/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:59:16', '2018-09-16 18:59:16'),
(45, 1, 'admin/auth/permissions', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:59:21', '2018-09-16 18:59:21'),
(46, 1, 'admin/auth/permissions/1/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:59:29', '2018-09-16 18:59:29'),
(47, 1, 'admin/auth/permissions/1', 'PUT', '192.168.6.49', '{"slug":"*","name":"\\u6240\\u6709\\u6743\\u9650","http_method":[null],"http_path":"*","_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/permissions"}', '2018-09-16 18:59:49', '2018-09-16 18:59:49'),
(48, 1, 'admin/auth/permissions', 'GET', '192.168.6.49', '[]', '2018-09-16 18:59:50', '2018-09-16 18:59:50'),
(49, 1, 'admin/auth/permissions/2/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 18:59:54', '2018-09-16 18:59:54'),
(50, 1, 'admin/auth/permissions/2', 'PUT', '192.168.6.49', '{"slug":"dashboard","name":"\\u63a7\\u5236\\u9762\\u677f","http_method":["GET",null],"http_path":"\\/","_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/permissions"}', '2018-09-16 19:00:23', '2018-09-16 19:00:23'),
(51, 1, 'admin/auth/permissions', 'GET', '192.168.6.49', '[]', '2018-09-16 19:00:23', '2018-09-16 19:00:23'),
(52, 1, 'admin/auth/permissions/3/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:00:30', '2018-09-16 19:00:30'),
(53, 1, 'admin/auth/permissions/3', 'PUT', '192.168.6.49', '{"slug":"auth.login","name":"\\u767b\\u5f55\\u6743\\u9650","http_method":[null],"http_path":"\\/auth\\/login\\r\\n\\/auth\\/logout","_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/permissions"}', '2018-09-16 19:00:40', '2018-09-16 19:00:40'),
(54, 1, 'admin/auth/permissions', 'GET', '192.168.6.49', '[]', '2018-09-16 19:00:40', '2018-09-16 19:00:40'),
(55, 1, 'admin/auth/permissions/4/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:00:44', '2018-09-16 19:00:44'),
(56, 1, 'admin/auth/permissions/4', 'PUT', '192.168.6.49', '{"slug":"auth.setting","name":"\\u7528\\u6237\\u8bbe\\u7f6e\\u6743\\u9650","http_method":["GET","PUT",null],"http_path":"\\/auth\\/setting","_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/permissions"}', '2018-09-16 19:00:52', '2018-09-16 19:00:52'),
(57, 1, 'admin/auth/permissions', 'GET', '192.168.6.49', '[]', '2018-09-16 19:00:52', '2018-09-16 19:00:52'),
(58, 1, 'admin/auth/permissions/5/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:01:02', '2018-09-16 19:01:02'),
(59, 1, 'admin/auth/permissions/5', 'PUT', '192.168.6.49', '{"slug":"auth.management","name":"\\u6743\\u9650\\u7ba1\\u7406","http_method":[null],"http_path":"\\/auth\\/roles\\r\\n\\/auth\\/permissions\\r\\n\\/auth\\/menu\\r\\n\\/auth\\/logs","_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/permissions"}', '2018-09-16 19:01:13', '2018-09-16 19:01:13'),
(60, 1, 'admin/auth/permissions', 'GET', '192.168.6.49', '[]', '2018-09-16 19:01:14', '2018-09-16 19:01:14'),
(61, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:01:23', '2018-09-16 19:01:23'),
(62, 1, 'admin/auth/users', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:01:26', '2018-09-16 19:01:26'),
(63, 1, 'admin/auth/users/1/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:01:34', '2018-09-16 19:01:34'),
(64, 1, 'admin/auth/users/1', 'PUT', '192.168.6.49', '{"username":"admin","name":"\\u8d85\\u7ea7\\u7ba1\\u7406\\u5458","password":"$2y$10$rlHvYcF9sfTiC0RmA28trOED2ro2p0pXj0Ld3OYaCRroeL9TNmqwi","password_confirmation":"$2y$10$rlHvYcF9sfTiC0RmA28trOED2ro2p0pXj0Ld3OYaCRroeL9TNmqwi","roles":["1",null],"permissions":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/users"}', '2018-09-16 19:01:45', '2018-09-16 19:01:45'),
(65, 1, 'admin/auth/users', 'GET', '192.168.6.49', '[]', '2018-09-16 19:01:46', '2018-09-16 19:01:46'),
(66, 1, 'admin/auth/users', 'GET', '192.168.6.49', '[]', '2018-09-16 19:02:01', '2018-09-16 19:02:01'),
(67, 1, 'admin/auth/users', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:02:04', '2018-09-16 19:02:04'),
(68, 1, 'admin/auth/roles', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:02:06', '2018-09-16 19:02:06'),
(69, 1, 'admin/auth/permissions', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:02:12', '2018-09-16 19:02:12'),
(70, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:02:14', '2018-09-16 19:02:14'),
(71, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:02:32', '2018-09-16 19:02:32'),
(72, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:02:44', '2018-09-16 19:02:44'),
(73, 1, 'admin/auth/menu/2/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:02:54', '2018-09-16 19:02:54'),
(74, 1, 'admin/auth/menu/2', 'PUT', '192.168.6.49', '{"parent_id":"0","title":"\\u7528\\u6237\\u8bbe\\u7f6e","icon":"fa-users","uri":null,"roles":["1",null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/menu"}', '2018-09-16 19:03:17', '2018-09-16 19:03:17'),
(75, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 19:03:17', '2018-09-16 19:03:17'),
(76, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 19:03:23', '2018-09-16 19:03:23'),
(77, 1, 'admin/auth/menu/3/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:03:33', '2018-09-16 19:03:33'),
(78, 1, 'admin/auth/users', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:03:37', '2018-09-16 19:03:37'),
(79, 1, 'admin/auth/users', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:03:39', '2018-09-16 19:03:39'),
(80, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:03:42', '2018-09-16 19:03:42'),
(81, 1, 'admin/auth/menu/2/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:03:45', '2018-09-16 19:03:45'),
(82, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:04:11', '2018-09-16 19:04:11'),
(83, 1, 'admin/auth/menu/3/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:04:14', '2018-09-16 19:04:14'),
(84, 1, 'admin/auth/menu/3', 'PUT', '192.168.6.49', '{"parent_id":"2","title":"\\u7528\\u6237\\u7ba1\\u7406","icon":"fa-users","uri":"auth\\/users","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/menu"}', '2018-09-16 19:04:32', '2018-09-16 19:04:32'),
(85, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 19:04:32', '2018-09-16 19:04:32'),
(86, 1, 'admin/auth/menu/3/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:04:36', '2018-09-16 19:04:36'),
(87, 1, 'admin/auth/menu/3', 'PUT', '192.168.6.49', '{"parent_id":"2","title":"\\u7528\\u6237\\u7ba1\\u7406","icon":"fa-user-plus","uri":"auth\\/users","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/menu"}', '2018-09-16 19:05:03', '2018-09-16 19:05:03'),
(88, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 19:05:04', '2018-09-16 19:05:04'),
(89, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 19:05:08', '2018-09-16 19:05:08'),
(90, 1, 'admin/auth/menu/4/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:05:15', '2018-09-16 19:05:15'),
(91, 1, 'admin/auth/menu/4', 'PUT', '192.168.6.49', '{"parent_id":"2","title":"\\u89d2\\u8272\\u7ba1\\u7406","icon":"fa-user","uri":"auth\\/roles","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/menu"}', '2018-09-16 19:05:44', '2018-09-16 19:05:44'),
(92, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 19:05:44', '2018-09-16 19:05:44'),
(93, 1, 'admin/auth/menu/5/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:05:49', '2018-09-16 19:05:49'),
(94, 1, 'admin/auth/menu/5', 'PUT', '192.168.6.49', '{"parent_id":"2","title":"\\u6743\\u9650\\u7ba1\\u7406","icon":"fa-ban","uri":"auth\\/permissions","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/menu"}', '2018-09-16 19:06:06', '2018-09-16 19:06:06'),
(95, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 19:06:06', '2018-09-16 19:06:06'),
(96, 1, 'admin/auth/menu/5/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:06:11', '2018-09-16 19:06:11'),
(97, 1, 'admin/auth/menu/5', 'PUT', '192.168.6.49', '{"parent_id":"2","title":"\\u6743\\u9650\\u7ba1\\u7406","icon":"fa-ban","uri":"auth\\/permissions","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/menu"}', '2018-09-16 19:06:26', '2018-09-16 19:06:26'),
(98, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 19:06:26', '2018-09-16 19:06:26'),
(99, 1, 'admin/auth/menu/6/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:06:37', '2018-09-16 19:06:37'),
(100, 1, 'admin/auth/menu/6', 'PUT', '192.168.6.49', '{"parent_id":"2","title":"\\u83dc\\u5355\\u7ba1\\u7406","icon":"fa-bars","uri":"auth\\/menu","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/menu"}', '2018-09-16 19:06:52', '2018-09-16 19:06:52'),
(101, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 19:06:53', '2018-09-16 19:06:53'),
(102, 1, 'admin/auth/menu/6/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:06:58', '2018-09-16 19:06:58'),
(103, 1, 'admin/auth/menu/6', 'PUT', '192.168.6.49', '{"parent_id":"2","title":"\\u83dc\\u5355\\u7ba1\\u7406","icon":"fa-bars","uri":"auth\\/menu","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/menu"}', '2018-09-16 19:07:20', '2018-09-16 19:07:20'),
(104, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 19:07:21', '2018-09-16 19:07:21'),
(105, 1, 'admin/auth/menu/6/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:07:26', '2018-09-16 19:07:26'),
(106, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:07:32', '2018-09-16 19:07:32'),
(107, 1, 'admin/auth/menu/6/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:07:37', '2018-09-16 19:07:37'),
(108, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:08:01', '2018-09-16 19:08:01'),
(109, 1, 'admin/auth/menu/7/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:08:10', '2018-09-16 19:08:10'),
(110, 1, 'admin/auth/menu/7', 'PUT', '192.168.6.49', '{"parent_id":"2","title":"\\u64cd\\u4f5c\\u65e5\\u5fd7","icon":"fa-book","uri":"auth\\/logs","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/menu"}', '2018-09-16 19:08:44', '2018-09-16 19:08:44'),
(111, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 19:08:44', '2018-09-16 19:08:44'),
(112, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 19:08:47', '2018-09-16 19:08:47'),
(113, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:08:59', '2018-09-16 19:08:59'),
(114, 1, 'admin/auth/permissions', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:09:00', '2018-09-16 19:09:00'),
(115, 1, 'admin/auth/roles', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:09:03', '2018-09-16 19:09:03'),
(116, 1, 'admin/auth/users', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:09:04', '2018-09-16 19:09:04'),
(117, 1, 'admin/auth/users', 'GET', '192.168.6.49', '[]', '2018-09-16 19:14:29', '2018-09-16 19:14:29'),
(118, 1, 'admin/auth/users', 'GET', '192.168.6.49', '[]', '2018-09-16 19:14:34', '2018-09-16 19:14:34'),
(119, 1, 'admin/auth/users', 'GET', '192.168.6.49', '[]', '2018-09-16 19:14:37', '2018-09-16 19:14:37'),
(120, 1, 'admin/auth/users', 'GET', '192.168.6.49', '[]', '2018-09-16 19:14:39', '2018-09-16 19:14:39'),
(121, 1, 'admin/auth/users', 'GET', '192.168.6.49', '[]', '2018-09-16 19:14:42', '2018-09-16 19:14:42'),
(122, 1, 'admin/auth/users', 'GET', '192.168.6.49', '[]', '2018-09-16 19:14:54', '2018-09-16 19:14:54'),
(123, 1, 'admin/auth/users', 'GET', '192.168.6.49', '[]', '2018-09-16 19:17:12', '2018-09-16 19:17:12'),
(124, 1, 'admin/auth/users', 'GET', '192.168.6.49', '[]', '2018-09-16 19:17:16', '2018-09-16 19:17:16'),
(125, 1, 'admin/auth/users', 'GET', '192.168.6.49', '[]', '2018-09-16 19:19:02', '2018-09-16 19:19:02'),
(126, 1, 'admin/auth/users', 'GET', '192.168.6.49', '[]', '2018-09-16 19:19:19', '2018-09-16 19:19:19'),
(127, 1, 'admin/auth/users', 'GET', '192.168.6.49', '[]', '2018-09-16 19:19:43', '2018-09-16 19:19:43'),
(128, 1, 'admin/auth/users', 'GET', '192.168.6.49', '[]', '2018-09-16 19:20:05', '2018-09-16 19:20:05'),
(129, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:20:08', '2018-09-16 19:20:08'),
(130, 1, 'admin', 'GET', '192.168.6.49', '[]', '2018-09-16 19:31:26', '2018-09-16 19:31:26'),
(131, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 19:31:35', '2018-09-16 19:31:35'),
(132, 1, 'admin', 'GET', '192.168.6.49', '[]', '2018-09-16 19:32:05', '2018-09-16 19:32:05'),
(133, 1, 'admin', 'GET', '192.168.6.49', '[]', '2018-09-16 19:32:30', '2018-09-16 19:32:30'),
(134, 1, 'admin', 'GET', '192.168.6.49', '[]', '2018-09-16 19:33:44', '2018-09-16 19:33:44'),
(135, 1, 'admin', 'GET', '192.168.6.49', '[]', '2018-09-16 19:34:45', '2018-09-16 19:34:45'),
(136, 1, 'admin', 'GET', '192.168.6.49', '[]', '2018-09-16 21:15:07', '2018-09-16 21:15:07'),
(137, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:19:09', '2018-09-16 22:19:09'),
(138, 1, 'admin/auth/users', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:19:24', '2018-09-16 22:19:24'),
(139, 1, 'admin/auth/roles', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:19:25', '2018-09-16 22:19:25'),
(140, 1, 'admin/auth/permissions', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:19:26', '2018-09-16 22:19:26'),
(141, 1, 'admin/auth/permissions', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:19:27', '2018-09-16 22:19:27'),
(142, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:19:28', '2018-09-16 22:19:28'),
(143, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:19:29', '2018-09-16 22:19:29'),
(144, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:19:50', '2018-09-16 22:19:50'),
(145, 1, 'admin/auth/permissions', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:19:52', '2018-09-16 22:19:52'),
(146, 1, 'admin/auth/roles', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:19:52', '2018-09-16 22:19:52'),
(147, 1, 'admin/auth/users', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:19:54', '2018-09-16 22:19:54'),
(148, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:19:59', '2018-09-16 22:19:59'),
(149, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:20:04', '2018-09-16 22:20:04'),
(150, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:20:07', '2018-09-16 22:20:07'),
(151, 1, 'admin/auth/users', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:28:22', '2018-09-16 22:28:22'),
(152, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:28:30', '2018-09-16 22:28:30'),
(153, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"parent_id":"0","title":"\\u4f1a\\u5458\\u7ba1\\u7406","icon":"fa-user-md","uri":"users","roles":["1",null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz"}', '2018-09-16 22:29:24', '2018-09-16 22:29:24'),
(154, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 22:29:24', '2018-09-16 22:29:24'),
(155, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 22:29:29', '2018-09-16 22:29:29'),
(156, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:29:32', '2018-09-16 22:29:32'),
(157, 1, 'admin/auth/menu/8/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:29:35', '2018-09-16 22:29:35'),
(158, 1, 'admin/auth/menu/8', 'PUT', '192.168.6.49', '{"parent_id":"0","title":"\\u4f1a\\u5458\\u7ba1\\u7406","icon":"fa-user-md","uri":null,"roles":["1",null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/menu"}', '2018-09-16 22:29:39', '2018-09-16 22:29:39'),
(159, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 22:29:39', '2018-09-16 22:29:39'),
(160, 1, 'admin', 'GET', '192.168.6.49', '[]', '2018-09-16 22:29:50', '2018-09-16 22:29:50'),
(161, 1, 'admin', 'GET', '192.168.6.49', '[]', '2018-09-16 22:29:51', '2018-09-16 22:29:51'),
(162, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:29:52', '2018-09-16 22:29:52'),
(163, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:29:56', '2018-09-16 22:29:56'),
(164, 1, 'admin/auth/menu/8/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:30:08', '2018-09-16 22:30:08'),
(165, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:30:11', '2018-09-16 22:30:11'),
(166, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"parent_id":"8","title":"\\u4f1a\\u5458\\u5217\\u8868","icon":"fa-user-plus","uri":"users","roles":["1",null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz"}', '2018-09-16 22:30:42', '2018-09-16 22:30:42'),
(167, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 22:30:43', '2018-09-16 22:30:43'),
(168, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 22:30:44', '2018-09-16 22:30:44'),
(169, 1, 'admin/auth/menu/9/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:31:31', '2018-09-16 22:31:31'),
(170, 1, 'admin/auth/menu/9', 'PUT', '192.168.6.49', '{"parent_id":"8","title":"\\u4f1a\\u5458\\u5217\\u8868","icon":"fa-user-plus","uri":"\\/users","roles":["1",null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/menu"}', '2018-09-16 22:31:36', '2018-09-16 22:31:36'),
(171, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 22:31:37', '2018-09-16 22:31:37'),
(172, 1, 'admin', 'GET', '192.168.6.49', '[]', '2018-09-16 22:37:57', '2018-09-16 22:37:57'),
(173, 1, 'admin', 'GET', '192.168.6.49', '[]', '2018-09-16 22:37:58', '2018-09-16 22:37:58'),
(174, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:38:06', '2018-09-16 22:38:06'),
(175, 1, 'admin/auth/menu/9/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:38:08', '2018-09-16 22:38:08'),
(176, 1, 'admin/auth/menu/9/edit', 'GET', '192.168.6.49', '[]', '2018-09-16 22:38:23', '2018-09-16 22:38:23'),
(177, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:38:32', '2018-09-16 22:38:32'),
(178, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 22:42:04', '2018-09-16 22:42:04'),
(179, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 22:42:21', '2018-09-16 22:42:21'),
(180, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 22:42:22', '2018-09-16 22:42:22'),
(181, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 22:42:25', '2018-09-16 22:42:25'),
(182, 1, 'admin/auth/roles', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:43:13', '2018-09-16 22:43:13'),
(183, 1, 'admin/auth/users', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:43:13', '2018-09-16 22:43:13'),
(184, 1, 'admin/auth/permissions', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:43:15', '2018-09-16 22:43:15'),
(185, 1, 'admin', 'GET', '192.168.6.49', '[]', '2018-09-16 22:43:20', '2018-09-16 22:43:20'),
(186, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:45:30', '2018-09-16 22:45:30'),
(187, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"parent_id":"0","title":"\\u5e7f\\u544a\\u7ba1\\u7406","icon":"fa-bullhorn","uri":null,"roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz"}', '2018-09-16 22:51:50', '2018-09-16 22:51:50'),
(188, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 22:51:51', '2018-09-16 22:51:51'),
(189, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 22:51:55', '2018-09-16 22:51:55'),
(190, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:52:02', '2018-09-16 22:52:02'),
(191, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:55:31', '2018-09-16 22:55:31'),
(192, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:58:38', '2018-09-16 22:58:38'),
(193, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 22:58:47', '2018-09-16 22:58:47'),
(194, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"parent_id":"10","title":"\\u5e7f\\u544a\\u5217\\u8868","icon":"fa-image","uri":"\\/ads","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz"}', '2018-09-16 22:59:39', '2018-09-16 22:59:39'),
(195, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 22:59:39', '2018-09-16 22:59:39'),
(196, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"parent_id":"0","title":"\\u7cfb\\u7edf\\u7ba1\\u7406","icon":"fa-cog","uri":null,"roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz"}', '2018-09-16 23:01:46', '2018-09-16 23:01:46'),
(197, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:01:46', '2018-09-16 23:01:46'),
(198, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_order":"[{\\"id\\":1},{\\"id\\":12},{\\"id\\":2,\\"children\\":[{\\"id\\":3},{\\"id\\":4},{\\"id\\":5},{\\"id\\":6},{\\"id\\":7}]},{\\"id\\":8,\\"children\\":[{\\"id\\":9}]},{\\"id\\":10,\\"children\\":[{\\"id\\":11}]}]"}', '2018-09-16 23:02:02', '2018-09-16 23:02:02'),
(199, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:02:02', '2018-09-16 23:02:02'),
(200, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:03:09', '2018-09-16 23:03:09'),
(201, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:04:04', '2018-09-16 23:04:04'),
(202, 1, 'admin', 'GET', '192.168.6.49', '[]', '2018-09-16 23:05:39', '2018-09-16 23:05:39'),
(203, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:05:43', '2018-09-16 23:05:43'),
(204, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:05:44', '2018-09-16 23:05:44'),
(205, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:05:45', '2018-09-16 23:05:45'),
(206, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:10:24', '2018-09-16 23:10:24'),
(207, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:10:25', '2018-09-16 23:10:25'),
(208, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:10:27', '2018-09-16 23:10:27'),
(209, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:10:29', '2018-09-16 23:10:29'),
(210, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:11:04', '2018-09-16 23:11:04'),
(211, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"parent_id":"0","title":"\\u7edf\\u8ba1\\u7ba1\\u7406","icon":"fa-bar-chart-o","uri":null,"roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz"}', '2018-09-16 23:11:23', '2018-09-16 23:11:23'),
(212, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:11:23', '2018-09-16 23:11:23'),
(213, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"parent_id":"0","title":"\\u7edf\\u8ba1\\u5217\\u8868","icon":"fa-pie-chart","uri":"chart","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz"}', '2018-09-16 23:12:35', '2018-09-16 23:12:35'),
(214, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:12:35', '2018-09-16 23:12:35'),
(215, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:12:39', '2018-09-16 23:12:39'),
(216, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_order":"[{\\"id\\":1},{\\"id\\":12},{\\"id\\":2,\\"children\\":[{\\"id\\":3},{\\"id\\":4},{\\"id\\":5},{\\"id\\":6},{\\"id\\":7}]},{\\"id\\":8,\\"children\\":[{\\"id\\":9}]},{\\"id\\":10,\\"children\\":[{\\"id\\":11}]},{\\"id\\":13,\\"children\\":[{\\"id\\":14}]}]"}', '2018-09-16 23:12:52', '2018-09-16 23:12:52'),
(217, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:12:52', '2018-09-16 23:12:52'),
(218, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:12:53', '2018-09-16 23:12:53'),
(219, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:13:01', '2018-09-16 23:13:01'),
(220, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:13:02', '2018-09-16 23:13:02'),
(221, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:13:53', '2018-09-16 23:13:53'),
(222, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"parent_id":"0","title":"\\u6587\\u7ae0\\u7ba1\\u7406","icon":"fa-send-o","uri":null,"roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz"}', '2018-09-16 23:16:10', '2018-09-16 23:16:10'),
(223, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:16:10', '2018-09-16 23:16:10'),
(224, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:16:12', '2018-09-16 23:16:12'),
(225, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:17:14', '2018-09-16 23:17:14'),
(226, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:18:21', '2018-09-16 23:18:21'),
(227, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:19:49', '2018-09-16 23:19:49'),
(228, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"parent_id":"15","title":"\\u6587\\u7ae0\\u5206\\u7c7b","icon":"fa-list-alt","uri":"category","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz"}', '2018-09-16 23:21:40', '2018-09-16 23:21:40'),
(229, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:21:41', '2018-09-16 23:21:41'),
(230, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"parent_id":"15","title":"\\u6587\\u7ae0\\u5217\\u8868","icon":"fa-list-ol","uri":null,"roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz"}', '2018-09-16 23:22:01', '2018-09-16 23:22:01'),
(231, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:22:02', '2018-09-16 23:22:02'),
(232, 1, 'admin/auth/menu/17/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:22:05', '2018-09-16 23:22:05'),
(233, 1, 'admin/auth/menu/17', 'PUT', '192.168.6.49', '{"parent_id":"15","title":"\\u6587\\u7ae0\\u5217\\u8868","icon":"fa-list-ol","uri":"artlist","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/menu"}', '2018-09-16 23:22:15', '2018-09-16 23:22:15'),
(234, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:22:16', '2018-09-16 23:22:16'),
(235, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:22:18', '2018-09-16 23:22:18'),
(236, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:22:44', '2018-09-16 23:22:44'),
(237, 1, 'admin', 'GET', '192.168.6.49', '[]', '2018-09-16 23:22:46', '2018-09-16 23:22:46'),
(238, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:24:06', '2018-09-16 23:24:06'),
(239, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:24:10', '2018-09-16 23:24:10'),
(240, 1, 'admin/auth/menu/17/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:24:17', '2018-09-16 23:24:17'),
(241, 1, 'admin/auth/menu/17', 'PUT', '192.168.6.49', '{"parent_id":"15","title":"\\u6587\\u7ae0\\u5217\\u8868","icon":"fa-list-ol","uri":"articles","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/menu"}', '2018-09-16 23:24:23', '2018-09-16 23:24:23'),
(242, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:24:23', '2018-09-16 23:24:23'),
(243, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_order":"[{\\"id\\":1},{\\"id\\":15,\\"children\\":[{\\"id\\":16},{\\"id\\":17}]},{\\"id\\":8,\\"children\\":[{\\"id\\":9}]},{\\"id\\":12},{\\"id\\":2,\\"children\\":[{\\"id\\":3},{\\"id\\":4},{\\"id\\":5},{\\"id\\":6},{\\"id\\":7}]},{\\"id\\":10,\\"children\\":[{\\"id\\":11}]},{\\"id\\":13,\\"children\\":[{\\"id\\":14}]}]"}', '2018-09-16 23:26:37', '2018-09-16 23:26:37'),
(244, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:26:37', '2018-09-16 23:26:37'),
(245, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:26:55', '2018-09-16 23:26:55'),
(246, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:27:11', '2018-09-16 23:27:11'),
(247, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:27:31', '2018-09-16 23:27:31'),
(248, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:27:34', '2018-09-16 23:27:34'),
(249, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"parent_id":"0","title":"\\u6570\\u636e\\u5e93\\u7ba1\\u7406","icon":"fa-database","uri":null,"roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz"}', '2018-09-16 23:27:54', '2018-09-16 23:27:54'),
(250, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:27:54', '2018-09-16 23:27:54'),
(251, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"parent_id":"0","title":"\\u8ba2\\u5355\\u7ba1\\u7406","icon":"fa-cart-plus","uri":null,"roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz"}', '2018-09-16 23:38:18', '2018-09-16 23:38:18'),
(252, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:38:19', '2018-09-16 23:38:19'),
(253, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:38:20', '2018-09-16 23:38:20'),
(254, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"parent_id":"19","title":"\\u8ba2\\u5355\\u5217\\u8868","icon":"fa-ambulance","uri":"orders","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz"}', '2018-09-16 23:39:35', '2018-09-16 23:39:35'),
(255, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:39:35', '2018-09-16 23:39:35'),
(256, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:39:37', '2018-09-16 23:39:37'),
(257, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_order":"[{\\"id\\":1},{\\"id\\":15,\\"children\\":[{\\"id\\":16},{\\"id\\":17}]},{\\"id\\":19,\\"children\\":[{\\"id\\":20}]},{\\"id\\":8,\\"children\\":[{\\"id\\":9}]},{\\"id\\":12},{\\"id\\":2,\\"children\\":[{\\"id\\":3},{\\"id\\":4},{\\"id\\":5},{\\"id\\":6},{\\"id\\":7}]},{\\"id\\":10,\\"children\\":[{\\"id\\":11}]},{\\"id\\":13,\\"children\\":[{\\"id\\":14}]},{\\"id\\":18}]"}', '2018-09-16 23:40:01', '2018-09-16 23:40:01'),
(258, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:40:01', '2018-09-16 23:40:01'),
(259, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:40:02', '2018-09-16 23:40:02'),
(260, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:41:44', '2018-09-16 23:41:44'),
(261, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:41:46', '2018-09-16 23:41:46'),
(262, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:41:47', '2018-09-16 23:41:47'),
(263, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:42:59', '2018-09-16 23:42:59'),
(264, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:43:09', '2018-09-16 23:43:09'),
(265, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"parent_id":"0","title":"\\u79ef\\u5206\\u7ba1\\u7406","icon":"fa-money","uri":null,"roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz"}', '2018-09-16 23:44:22', '2018-09-16 23:44:22'),
(266, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:44:22', '2018-09-16 23:44:22'),
(267, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"parent_id":"0","title":"\\u79ef\\u5206\\u5151\\u6362","icon":"fa-balance-scale","uri":"exchange","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz"}', '2018-09-16 23:46:06', '2018-09-16 23:46:06'),
(268, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:46:07', '2018-09-16 23:46:07'),
(269, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_order":"[{\\"id\\":1},{\\"id\\":15,\\"children\\":[{\\"id\\":16},{\\"id\\":17}]},{\\"id\\":19,\\"children\\":[{\\"id\\":20}]},{\\"id\\":8,\\"children\\":[{\\"id\\":9}]},{\\"id\\":12},{\\"id\\":2,\\"children\\":[{\\"id\\":3},{\\"id\\":4},{\\"id\\":5},{\\"id\\":6},{\\"id\\":7}]},{\\"id\\":10,\\"children\\":[{\\"id\\":11}]},{\\"id\\":13,\\"children\\":[{\\"id\\":14}]},{\\"id\\":18},{\\"id\\":21,\\"children\\":[{\\"id\\":22}]}]"}', '2018-09-16 23:46:16', '2018-09-16 23:46:16'),
(270, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:46:17', '2018-09-16 23:46:17'),
(271, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"parent_id":"0","title":"\\u652f\\u4ed8\\u65b9\\u5f0f","icon":"fa-cc-paypal","uri":null,"roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz"}', '2018-09-16 23:46:41', '2018-09-16 23:46:41'),
(272, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:46:42', '2018-09-16 23:46:42'),
(273, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:46:44', '2018-09-16 23:46:44'),
(274, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:47:05', '2018-09-16 23:47:05'),
(275, 1, 'admin', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:47:08', '2018-09-16 23:47:08'),
(276, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:47:23', '2018-09-16 23:47:23'),
(277, 1, 'admin/auth/menu/23/edit', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:47:26', '2018-09-16 23:47:26'),
(278, 1, 'admin/auth/menu/23', 'PUT', '192.168.6.49', '{"parent_id":"0","title":"\\u652f\\u4ed8\\u65b9\\u5f0f","icon":"fa-cc-paypal","uri":"payment","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_method":"PUT","_previous_":"http:\\/\\/mobanw.cn\\/admin\\/auth\\/menu"}', '2018-09-16 23:47:48', '2018-09-16 23:47:48'),
(279, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:47:49', '2018-09-16 23:47:49'),
(280, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:47:50', '2018-09-16 23:47:50'),
(281, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"parent_id":"12","title":"\\u7cfb\\u7edf\\u8bbe\\u7f6e","icon":"fa-cogs","uri":"setting","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz"}', '2018-09-16 23:49:13', '2018-09-16 23:49:13'),
(282, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:49:13', '2018-09-16 23:49:13'),
(283, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:51:54', '2018-09-16 23:51:54'),
(284, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:54:04', '2018-09-16 23:54:04'),
(285, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"parent_id":"0","title":"\\u6570\\u636e\\u5e93\\u5907\\u4efd","icon":"fa-arrow-down","uri":"backup","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz"}', '2018-09-16 23:55:34', '2018-09-16 23:55:34'),
(286, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:55:34', '2018-09-16 23:55:34'),
(287, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_order":"[{\\"id\\":1},{\\"id\\":15,\\"children\\":[{\\"id\\":16},{\\"id\\":17}]},{\\"id\\":19,\\"children\\":[{\\"id\\":20}]},{\\"id\\":8,\\"children\\":[{\\"id\\":9}]},{\\"id\\":12,\\"children\\":[{\\"id\\":24}]},{\\"id\\":2,\\"children\\":[{\\"id\\":3},{\\"id\\":4},{\\"id\\":5},{\\"id\\":6},{\\"id\\":7}]},{\\"id\\":10,\\"children\\":[{\\"id\\":11}]},{\\"id\\":13,\\"children\\":[{\\"id\\":14}]},{\\"id\\":18,\\"children\\":[{\\"id\\":25}]},{\\"id\\":21,\\"children\\":[{\\"id\\":22}]},{\\"id\\":23}]"}', '2018-09-16 23:55:46', '2018-09-16 23:55:46'),
(288, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:55:47', '2018-09-16 23:55:47'),
(289, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"parent_id":"0","title":"\\u6570\\u636e\\u5e93\\u8fd8\\u539f","icon":"fa-arrow-up","uri":"restore","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz"}', '2018-09-16 23:56:21', '2018-09-16 23:56:21'),
(290, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-16 23:56:21', '2018-09-16 23:56:21'),
(291, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz","_order":"[{\\"id\\":1},{\\"id\\":15,\\"children\\":[{\\"id\\":16},{\\"id\\":17}]},{\\"id\\":19,\\"children\\":[{\\"id\\":20}]},{\\"id\\":8,\\"children\\":[{\\"id\\":9}]},{\\"id\\":12,\\"children\\":[{\\"id\\":24}]},{\\"id\\":2,\\"children\\":[{\\"id\\":3},{\\"id\\":4},{\\"id\\":5},{\\"id\\":6},{\\"id\\":7}]},{\\"id\\":10,\\"children\\":[{\\"id\\":11}]},{\\"id\\":13,\\"children\\":[{\\"id\\":14}]},{\\"id\\":18,\\"children\\":[{\\"id\\":25},{\\"id\\":26}]},{\\"id\\":21,\\"children\\":[{\\"id\\":22}]},{\\"id\\":23}]"}', '2018-09-16 23:56:28', '2018-09-16 23:56:28'),
(292, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '{"_pjax":"#pjax-container"}', '2018-09-16 23:56:28', '2018-09-16 23:56:28'),
(293, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-17 00:31:03', '2018-09-17 00:31:03'),
(294, 1, 'admin/auth/menu', 'POST', '192.168.6.49', '{"parent_id":"0","title":"\\u8bc4\\u8bba\\u7ba1\\u7406","icon":"fa-comments","uri":"comment","roles":[null],"_token":"dsYszUOpddiVLtZl4yet7lxoNVYEaIxaTV434Zmz"}', '2018-09-17 00:32:13', '2018-09-17 00:32:13'),
(295, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-17 00:32:14', '2018-09-17 00:32:14'),
(296, 1, 'admin/auth/menu', 'GET', '192.168.6.49', '[]', '2018-09-17 00:32:17', '2018-09-17 00:32:17');

-- --------------------------------------------------------

--
-- 表的结构 `admin_permissions`
--

CREATE TABLE IF NOT EXISTS `admin_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `http_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `http_path` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_permissions_name_unique` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `admin_permissions`
--

INSERT INTO `admin_permissions` (`id`, `name`, `slug`, `http_method`, `http_path`, `created_at`, `updated_at`) VALUES
(1, '所有权限', '*', '', '*', NULL, '2018-09-16 18:59:49'),
(2, '控制面板', 'dashboard', 'GET', '/', NULL, '2018-09-16 19:00:23'),
(3, '登录权限', 'auth.login', '', '/auth/login\r\n/auth/logout', NULL, '2018-09-16 19:00:40'),
(4, '用户设置权限', 'auth.setting', 'GET,PUT', '/auth/setting', NULL, '2018-09-16 19:00:52'),
(5, '权限管理', 'auth.management', '', '/auth/roles\r\n/auth/permissions\r\n/auth/menu\r\n/auth/logs', NULL, '2018-09-16 19:01:13');

-- --------------------------------------------------------

--
-- 表的结构 `admin_roles`
--

CREATE TABLE IF NOT EXISTS `admin_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_roles_name_unique` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `admin_roles`
--

INSERT INTO `admin_roles` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, '超级管理员', 'admin', '2018-09-16 18:53:29', '2018-09-16 18:59:11');

-- --------------------------------------------------------

--
-- 表的结构 `admin_role_menu`
--

CREATE TABLE IF NOT EXISTS `admin_role_menu` (
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_role_menu_role_id_menu_id_index` (`role_id`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `admin_role_menu`
--

INSERT INTO `admin_role_menu` (`role_id`, `menu_id`, `created_at`, `updated_at`) VALUES
(1, 2, NULL, NULL),
(1, 8, NULL, NULL),
(1, 9, NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `admin_role_permissions`
--

CREATE TABLE IF NOT EXISTS `admin_role_permissions` (
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_role_permissions_role_id_permission_id_index` (`role_id`,`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `admin_role_permissions`
--

INSERT INTO `admin_role_permissions` (`role_id`, `permission_id`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `admin_role_users`
--

CREATE TABLE IF NOT EXISTS `admin_role_users` (
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_role_users_role_id_user_id_index` (`role_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `admin_role_users`
--

INSERT INTO `admin_role_users` (`role_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `admin_users`
--

CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_users_username_unique` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password`, `name`, `avatar`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2y$10$rlHvYcF9sfTiC0RmA28trOED2ro2p0pXj0Ld3OYaCRroeL9TNmqwi', '超级管理员', NULL, NULL, '2018-09-16 18:53:28', '2018-09-16 19:01:45');

-- --------------------------------------------------------

--
-- 表的结构 `admin_user_permissions`
--

CREATE TABLE IF NOT EXISTS `admin_user_permissions` (
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_user_permissions_user_id_permission_id_index` (`user_id`,`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- 表的结构 `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_01_04_173148_create_admin_tables', 1);

-- --------------------------------------------------------

--
-- 表的结构 `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- 表的结构 `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
